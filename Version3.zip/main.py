from time import sleep
print("Welcome to my Duck Hunting") #opening statement
sleep(2)
print("This game will be accessable on any device that has google, just copy the link.")
sleep(5)
print("Warning! In real life if you were to shoot any other than waterfowl or upland game you will be fined and depending possibly imprisoned.") #Relevant implication - Is it safe
sleep(10)
print("Please make sure in real life that you have your firearms license before handling a firearm.")
sleep(6)
#function to check yes or no only entered = works with any question
def yes_no_check(question):
  valid = False
  while not valid:   #it will keep aking the question until it gets a, b, c or d
    error = "Please enter a, b, c, or d"
    try:
      response = input(question)
      if response == "a" or response == "b" or response == "c" or response == "d":
        return response
      else:
        print(error)
    except TypeError:
      print(error)
#main program
print("You will be trialing a 12 gauge shotgun, you get a choice of a = Remington, b = Berreta, c = Benneli or  d = Churchill.")
#question to be asked
gun = yes_no_check("What type of shotgun do you want to use? a/b/c/d")   # Type of shotgun the user wants to use.
#program will only continue once Y or N is entered
sleep(2)
if gun == "a" or gun == "A":
  print("Great Remington is an excelent choice.")
elif gun == "b" or gun == "B":
  print("Great Berreta is an excelent choice.")
elif gun == "c" or gun == "C":
  print("Great Benneli is an excelent choice.")
elif gun == "d" or gun == "D":
  print("Great Churchill is an excelent choice.")
#score count
mallard=0
grey=0
paradise=0
canadian=0
swan=0
teal=0
ranger=0
friend=0
hunter=0
time=0
sleep(3)
name = input("What would you like to be called?") #player name
sleep(1)
print"Hello", name
sleep(2)
print("You will have a friend hunting with you.")
sleep(3)
friend1 = input("What do you want your friends name to be?") #friend name
sleep(1)
#function to check yes or no only entered = works with any question
def yes_no_check(question):
  valid = False
  while not valid:   #it will keep aking the question until it gets a, b, c or d
    error = "Please enter fog, blue sky, rain, windy, or cloudy"
    try:
      response = input(question)
      if response == "fog" or response == "blue sky" or response == "rain" or response == "windy" or response == "cloudy":
        return response
      else:
        print(error)
    except TypeError:
      print(error)
#question to be asked
setting = yes_no_check("What do you want the day to be like, Fog, Blue Sky, Rain, Windy or Cloudy?")   # Type of shotgun the user wants to use.
#program will only continue once Y or N is entered
sleep(1)
print("On the lake you have an option to shoot Swan, Canadian Geese, Paradise Ducks, Mallards, or Greys.")
sleep(6)
print("You can only hunt these birds, if you shoot any other species the game will stop and you will have your license taken!")
sleep(4)
#function to check yes or no only entered = works with any question
def yes_no_check(question):
  valid = False
  while not valid:   #it will keep asking the question until it gets Y or N
    error = "Please enter Y or N"
    try:
      response = input(question)
      if response == "Y" or response == "y" or response == "N" or response == "n":
        return response
      else:
        print(error)

    except TypeError:
      print(error)
#main program
print("It's 5:30am on Opening Morning. You are ready to head up the lake in your duck boat.")
#question to be asked
continue1 = yes_no_check("Do you wish to continue? y/n")
#program will only continue once Y or N is entered
sleep(2)
if continue1 == "Y" or continue1 == "y":
  print"Great, your friend is meeting you at the maimai. You hopped into the boat started the motor and you are heading up the lake in the", setting #head up lake
  sleep(6)
  print"After a 15 minute trip up the lake you arrive at the maimai. Your friend,", friend1, "is already there."
  sleep(4)
  print"Waiting in the maimai with", friend1, "you hear the first shots but it is still too early." #in maimai
  sleep(2)
  #function to check yes or no only entered = works with any question
  def yes_no_check(question):
    valid = False
    while not valid:   #it will keep asking the question until it gets Y or N
      error = "Please enter Y or N"
      try:
        response = input(question)
        if response == "Y" or response == "y" or response == "N" or response == "n":
          return response
        else:
          print(error)
      except TypeError:
        print(error)
  #main program
  print("You know you shouldn't but you see a duck flying in range.")
  #question to be asked
  early1 = yes_no_check("Do you wish to shoot it? y/n")
  #program will only continue once Y or N is entered
  if early1 == "Y" or early1 == "y":
    sleep(1)
    print("You stood up and shot it cleanly with one shot.")
    teal=teal+1
    sleep(2)
    print("Your friends dog retrieved it and it turned out to be a teal. Teals are illegal to shoot.") #illegal shot
    sleep(4)
    #function to check yes or no only entered = works with any question
    def yes_no_check(question):
      valid = False
      while not valid:   #it will keep asking the question until it gets y or n
        error = "Please enter Y or N"
        try:
          response = input(question)
          if response == "Y" or response == "y" or response == "N" or response == "n":
            return response
          else:
            print(error)
        except TypeError:
          print(error)
    #main program
    print("You turn around as a ranger knocks on the door.")
    #question to be asked
    ranger1 = yes_no_check("Do you wish to shoot the ranger? y/n")
    #program will only continue once Y or N is entered
    sleep(2)
    if ranger1 == "Y" or ranger1 == "y":
      sleep(1)
      ranger=ranger+1
      print("Two weeks later the police turn up and arrest you saying you are in for life sentence. You cannot escape!") #life sentence
      sleep(6)
      #final score count
      print("------------------------")
      sleep(2)
      print"Mallard Ducks Shot  =",mallard
      sleep(2)
      print"Grey Ducks Shot     =",grey
      sleep(2)
      print"Paradise Ducks Shot =",paradise
      sleep(2)
      print"Canadian Geese Shot =",canadian
      sleep(2)
      print"Black Swan Shot     =",swan
      sleep(2)
      print"Teal Ducks Shot     =",teal
      sleep(2)
      print"Rangers Shot        =",ranger
      sleep(2)
      print"Hunters Shot        =",hunter
      sleep(2)
      print("------------------------")
    elif ranger1 == "N" or ranger1 == "n":
      sleep(1)
      print("That's lucky as he had a mate with him. They take your license, gun, boat and car. They also give you a fine of $2000.") #$2000 fine
      sleep(6)
      #final tally
      print("------------------------")
      sleep(2)
      print"Mallard Ducks Shot  =",mallard
      sleep(2)
      print"Grey Ducks Shot     =",grey
      sleep(2)
      print"Paradise Ducks Shot =",paradise
      sleep(2)
      print"Canadian Geese Shot =",canadian
      sleep(2)
      print"Black Swan Shot     =",swan
      sleep(2)
      print"Teal Ducks Shot     =",teal
      sleep(2)
      print"Rangers Shot        =",ranger
      sleep(2)
      print"Hunters Shot        =",hunter
      sleep(2)
      print("------------------------")
  elif early1 == "N" or early1 == "n":
    sleep(1)
    print("Good decision as you know there are some rangers about this morning.") #good decision
    sleep(1)
    print("For every loop you have one game bird fly past.")
    loops=input("How many loops would you like to play for? 1-99") #amount of loops the player wants to play for
    if loops == 1-99:
      print("Great!")
      sleep(2)
      for x in range(0, time):
        sleep(1)
        import random
        token = ["Hunter", "Ranger", "Teal", "Mallard Duck", "Grey Duck", "Paradise Duck", "Swan", "Canadian Goose"] #random choice
        rps_choice = random.choice(token)
        print(rps_choice)
        sleep(1)
        if rps_choice == "Hunter" or rps_choice == "Ranger" or rps_choice == "Teal" or rps_choice == "Mallard Duck" or rps_choice == "Grey Duck" or rps_choice == "Paradise Duck" or rps_choice == "Swan" or rps_choice == "Canadian Goose":
          sleep(1)
          #function to check yes or no only entered = works with any question
          def yes_no_check(question):
            valid = False
            while not valid:   #it will keep asking the question until it gets y or n
              error = "Please enter Y or N"
              try:
                response = input(question)
                if response == "Y" or response == "y" or response == "N" or response == "n":
                  return response
                else:
                  print(error)
              except TypeError:
                print(error)
          #main program
          print"Through the", setting, "you see a", rps_choice, "close enough to shoot."
          #question to be asked
          duck1 = yes_no_check("Do you wish to shoot the bird? y/n")
          #program will only continue once Y or N is entered
          sleep(2)
          if duck1 == "Y" or duck1 == "y":
            import random
            token = ["1", "2", "3"]
            choice = random.choice(token) #random choice
            print(choice)
            if choice == "1" or choice == "2":
              if rps_choice == "Hunter" and hunter <=4:
                if hunter >=4:
                  sleep(1)
                  print("The Rangers turn up and arrest you saying you are in for life sentence. You cannot escape!") #life sentence
                  sleep(2) #final score
                  print("------------------------")
                  sleep(2)
                  print"Mallard Ducks Shot  =",mallard
                  sleep(2)
                  print"Grey Ducks Shot     =",grey
                  sleep(2)
                  print"Paradise Ducks Shot =",paradise
                  sleep(2)
                  print"Canadian Geese Shot =",canadian
                  sleep(2)
                  print"Black Swan Shot     =",swan
                  sleep(2)
                  print"Teal Ducks Shot     =",teal
                  sleep(2)
                  print"Rangers Shot        =",ranger
                  sleep(2)
                  print"Hunters Shot        =",hunter
                  sleep(2)
                  print("------------------------")
                  break
                elif hunter >=3:
                  sleep(1)
                  #function to check yes or no only entered = works with any question
                  def yes_no_check(question):
                    valid = False
                    while not valid:   #it will keep asking the question until it gets y or n
                      error = "Please enter Y or N"
                      try:
                        response = input(question)
                        if response == "Y" or response == "y" or response == "N" or response == "n":
                          return response
                        else:
                          print(error)
                      except TypeError:
                        print(error)
                  #main program
                  print("You have shot 3 or more Hunters, if you shoot any more you will be in trouble!")
                  #question to be asked
                  home6 = yes_no_check("Do you wish to head home before the rangers find out? y/n")
                  #program will only continue once Y or N is entered
                  sleep(3)
                  if home6 == "Y" or home6 == "y":
                    print("You leave before anyone finds out.")
                    sleep(2)
                    print("You head home with your ducks and have a delicious roast duck for dinner.")
                    sleep(3)
                    print("Two weeks later the police turn up and arrest you saying you are in for life sentence. You cannot escape!") #arrested
                    sleep(5)
                    print("Thanks for playing my Duck Hunting Game!")
                    sleep(2) #tally
                    print("------------------------")
                    sleep(2)
                    print"Mallard Ducks Shot  =",mallard
                    sleep(2)
                    print"Grey Ducks Shot     =",grey
                    sleep(2)
                    print"Paradise Ducks Shot =",paradise
                    sleep(2)
                    print"Canadian Geese Shot =",canadian
                    sleep(2)
                    print"Black Swan Shot     =",swan
                    sleep(2)
                    print"Teal Ducks Shot     =",teal
                    sleep(2)
                    print"Rangers Shot        =",ranger
                    sleep(2)
                    print"Hunters Shot        =",hunter
                    sleep(2)
                    print("------------------------")
                    break
                  elif home6 == "N" or home6 == "n":
                    print("The Rangers turn up and arrest you saying you are in for life sentence. You cannot escape!") #arrested
                elif hunter <=3:
                  hunter=hunter+1
                  sleep(1)
                  print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job" #hunter shot
              if rps_choice == "Ranger" and ranger <=3:
                if ranger >=3:
                  sleep(1)
                  print("The Rangers turn up and arrest you saying you are in for life sentence. You cannot escape!") #arrested
                  sleep(2) #final score
                  print("------------------------")
                  sleep(2)
                  print"Mallard Ducks Shot  =",mallard
                  sleep(2)
                  print"Grey Ducks Shot     =",grey
                  sleep(2)
                  print"Paradise Ducks Shot =",paradise
                  sleep(2)
                  print"Canadian Geese Shot =",canadian
                  sleep(2)
                  print"Black Swan Shot     =",swan
                  sleep(2)
                  print"Teal Ducks Shot     =",teal
                  sleep(2)
                  print"Rangers Shot        =",ranger
                  sleep(2)
                  print"Hunters Shot        =",hunter
                  sleep(2)
                  print("------------------------")
                  break
                elif ranger >=2:
                  sleep(1)
                  #function to check yes or no only entered = works with any question
                  def yes_no_check(question):
                    valid = False
                    while not valid:   #it will keep asking the question until it gets y or n
                      error = "Please enter Y or N"
                      try:
                        response = input(question)
                        if response == "Y" or response == "y" or response == "N" or response == "n":
                          return response
                        else:
                          print(error)
                      except TypeError:
                        print(error)
                  #main program
                  print("You have shot 2 or more Rangers, if you shoot any more you will be in trouble!")
                  #question to be asked
                  home7 = yes_no_check("Do you wish to head home before the other rangers find out? y/n")
                  #program will only continue once Y or N is entered
                  sleep(3)
                  if home7 == "Y" or home7 == "y":
                    print("You leave before anyone finds out.")
                    sleep(2)
                    print("You head home with your ducks and have a delicious roast duck for dinner.")
                    sleep(3)
                    print("Two weeks later the police turn up and arrest you saying you are in for life sentence. You cannot escape!") #arrested
                    sleep(5)
                    print("Thanks for playing my Duck Hunting Game!")
                    sleep(2) #final tally
                    print("------------------------")
                    sleep(2)
                    print"Mallard Ducks Shot  =",mallard
                    sleep(2)
                    print"Grey Ducks Shot     =",grey
                    sleep(2)
                    print"Paradise Ducks Shot =",paradise
                    sleep(2)
                    print"Canadian Geese Shot =",canadian
                    sleep(2)
                    print"Black Swan Shot     =",swan
                    sleep(2)
                    print"Teal Ducks Shot     =",teal
                    sleep(2)
                    print"Rangers Shot        =",ranger
                    sleep(2)
                    print"Hunters Shot        =",hunter
                    sleep(2)
                    print("------------------------")
                    break
                  elif home7 == "N" or home7 == "n":
                    print("The Rangers turn up and arrest you saying you are in for life sentence. You cannot escape!") #arrested
                elif ranger <=3:
                  ranger=ranger+1
                  sleep(1)
                  print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job" #ranger shot
              if rps_choice == "Teal" and teal <=5:
                if teal >=5:
                  sleep(1)
                  print("You shot more than your limit of Teal. They take your license, gun, boat and car. They also give you a fine of $2000.") #$2000 fine
                  sleep(2) #tally
                  print("------------------------")
                  sleep(2)
                  print"Mallard Ducks Shot  =",mallard
                  sleep(2)
                  print"Grey Ducks Shot     =",grey
                  sleep(2)
                  print"Paradise Ducks Shot =",paradise
                  sleep(2)
                  print"Canadian Geese Shot =",canadian
                  sleep(2)
                  print"Black Swan Shot     =",swan
                  sleep(2)
                  print"Teal Ducks Shot     =",teal
                  sleep(2)
                  print"Rangers Shot        =",ranger
                  sleep(2)
                  print"Hunters Shot        =",hunter
                  sleep(2)
                  print("------------------------")
                  break
                elif teal >=4:
                  sleep(1)
                  #function to check yes or no only entered = works with any question
                  def yes_no_check(question):
                    valid = False
                    while not valid:   #it will keep asking the question until it gets y or n
                      error = "Please enter Y or N"
                      try:
                        response = input(question)
                        if response == "Y" or response == "y" or response == "N" or response == "n":
                          return response
                        else:
                          print(error)
                      except TypeError:
                        print(error)
                  #main program
                  print("You enough Teal, if you shoot any more you will be in trouble!")
                  #question to be asked
                  home8 = yes_no_check("Do you wish to head home? y/n")
                  #program will only continue once Y or N is entered
                  if home8 == "Y" or home8 == "y":
                    sleep(2)
                    print("You head home with your ducks and have a delicious roast duck for dinner.")
                    sleep(4)
                    print("Thanks for playing my Duck Hunting Game!")
                    sleep(2) #final score
                    print("------------------------")
                    sleep(2)
                    print"Mallard Ducks Shot  =",mallard
                    sleep(2)
                    print"Grey Ducks Shot     =",grey
                    sleep(2)
                    print"Paradise Ducks Shot =",paradise
                    sleep(2)
                    print"Canadian Geese Shot =",canadian
                    sleep(2)
                    print"Black Swan Shot     =",swan
                    sleep(2)
                    print"Teal Ducks Shot     =",teal
                    sleep(2)
                    print"Rangers Shot        =",ranger
                    sleep(2)
                    print"Hunters Shot        =",hunter
                    sleep(2)
                    print("------------------------")
                    break
                  elif home8 == "N" or home8 == "n":
                    sleep(1)
                    print("Ok, you just can't shoot anymore Teal.")
                elif teal <=5:
                  teal=teal+1
                  sleep(1)
                  print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job" #teal shot
              if rps_choice == "Mallard Duck" and mallard <=7:
                if mallard >=7:
                  sleep(1)
                  print("You shot more than your limit of Mallard Ducks. They take your license, gun, boat and car. They also give you a fine of $2000.") #fine
                  sleep(2) #tally
                  print("------------------------")
                  sleep(2)
                  print"Mallard Ducks Shot  =",mallard
                  sleep(2)
                  print"Grey Ducks Shot     =",grey
                  sleep(2)
                  print"Paradise Ducks Shot =",paradise
                  sleep(2)
                  print"Canadian Geese Shot =",canadian
                  sleep(2)
                  print"Black Swan Shot     =",swan
                  sleep(2)
                  print"Teal Ducks Shot     =",teal
                  sleep(2)
                  print"Rangers Shot        =",ranger
                  sleep(2)
                  print"Hunters Shot        =",hunter
                  sleep(2)
                  print("------------------------")
                  break
                elif mallard >=6:
                  sleep(1)
                  #function to check yes or no only entered = works with any question
                  def yes_no_check(question):
                    valid = False
                    while not valid:   #it will keep asking the question until it gets y or n
                      error = "Please enter Y or N"
                      try:
                        response = input(question)
                        if response == "Y" or response == "y" or response == "N" or response == "n":
                          return response
                        else:
                          print(error)
                      except TypeError:
                        print(error)
                  #main program
                  print("You have your limit of Mallard Ducks, if you shoot any more you will be in trouble!")
                  #question to be asked
                  home1 = yes_no_check("You have you limit on Mallard Ducks, do you wish to head home? y/n")
                  #program will only continue once Y or N is entered
                  if home1 == "Y" or home1 == "y":
                    sleep(3)
                    print("You head home with your ducks and have a delicious roast duck for dinner.")
                    sleep(4)
                    print("Thanks for playing my Duck Hunting Game!")
                    sleep(2) #tally
                    print("------------------------")
                    sleep(2)
                    print"Mallard Ducks Shot  =",mallard
                    sleep(2)
                    print"Grey Ducks Shot     =",grey
                    sleep(2)
                    print"Paradise Ducks Shot =",paradise
                    sleep(2)
                    print"Canadian Geese Shot =",canadian
                    sleep(2)
                    print"Black Swan Shot     =",swan
                    sleep(2)
                    print"Teal Ducks Shot     =",teal
                    sleep(2)
                    print"Rangers Shot        =",ranger
                    sleep(2)
                    print"Hunters Shot        =",hunter
                    sleep(2)
                    print("------------------------")
                    break
                  elif home1 == "N" or home1 == "n":
                    sleep(3)
                    print("Ok, you just can't shoot anymore Mallard Ducks.")
                  elif mallard <=6:
                    mallard=mallard+1
                    sleep(1)
                    print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job" #mallard shot
              elif rps_choice == "Grey Duck" and grey <=7:
                if grey >=7:
                  sleep(1)
                  print("You shot more than your limit of Grey Ducks. They take your license, gun, boat and car. They also give you a fine of $2000.") #$2000 fine
                  sleep(2) #final score
                  print("------------------------")
                  sleep(2)
                  print"Mallard Ducks Shot  =",mallard
                  sleep(2)
                  print"Grey Ducks Shot     =",grey
                  sleep(2)
                  print"Paradise Ducks Shot =",paradise
                  sleep(2)
                  print"Canadian Geese Shot =",canadian
                  sleep(2)
                  print"Black Swan Shot     =",swan
                  sleep(2)
                  print"Teal Ducks Shot     =",teal
                  sleep(2)
                  print"Rangers Shot        =",ranger
                  sleep(2)
                  print"Hunters Shot        =",hunter
                  sleep(2)
                  print("------------------------")
                  break
                elif grey >=6:
                  sleep(1)
                  #function to check yes or no only entered = works with any question
                  def yes_no_check(question):
                    valid = False
                    while not valid:   #it will keep asking the question until it gets y or n
                      error = "Please enter Y or N"
                      try:
                        response = input(question)
                        if response == "Y" or response == "y" or response == "N" or response == "n":
                          return response
                        else:
                          print(error)
                      except TypeError:
                        print(error)
                  #main program
                  print("You have your limit of Grey Ducks, if you shoot any more you will be in trouble!")
                  #question to be asked
                  home2 = yes_no_check("You have you limit on Grey Ducks, do you wish to head home? y/n")
                  #program will only continue once Y or N is entered
                  if home2 == "Y" or home2 == "y":
                    print("You head home with your ducks and have a delicious roast duck for dinner.")
                    sleep(4)
                    print("Thanks for playing my Duck Hunting Game!")
                    sleep(2) #tally
                    print("------------------------")
                    sleep(2)
                    print"Mallard Ducks Shot  =",mallard
                    sleep(2)
                    print"Grey Ducks Shot     =",grey
                    sleep(2)
                    print"Paradise Ducks Shot =",paradise
                    sleep(2)
                    print"Canadian Geese Shot =",canadian
                    sleep(2)
                    print"Black Swan Shot     =",swan
                    sleep(2)
                    print"Teal Ducks Shot     =",teal
                    sleep(2)
                    print"Rangers Shot        =",ranger
                    sleep(2)
                    print"Hunters Shot        =",hunter
                    sleep(2)
                    print("------------------------")
                    break
                  elif home2 == "N" or home2 == "n":
                    print("Ok, you just can't shoot anymore Grey Ducks.")
                  elif grey <=6:
                    grey=grey+1
                    sleep(1)
                    print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job" #grey shot
              elif rps_choice == "Paradise Duck" and paradise <=7:
                if paradise >=7:
                  sleep(1)
                  print("You shot more than your limit of Paradise Ducks. They take your license, gun, boat and car. They also give you a fine of $2000.") #$2000 fine
                  sleep(2) #final score
                  print("------------------------")
                  sleep(2)
                  print"Mallard Ducks Shot  =",mallard
                  sleep(2)
                  print"Grey Ducks Shot     =",grey
                  sleep(2)
                  print"Paradise Ducks Shot =",paradise
                  sleep(2)
                  print"Canadian Geese Shot =",canadian
                  sleep(2)
                  print"Black Swan Shot     =",swan
                  sleep(2)
                  print"Teal Ducks Shot     =",teal
                  sleep(2)
                  print"Rangers Shot        =",ranger
                  sleep(2)
                  print"Hunters Shot        =",hunter
                  sleep(2)
                  print("------------------------")
                  break
                elif paradise >=6:
                  sleep(1)
                  #function to check yes or no only entered = works with any question
                  def yes_no_check(question):
                    valid = False
                    while not valid:   #it will keep asking the question until it gets y or n
                      error = "Please enter Y or N"
                      try:
                        response = input(question)
                        if response == "Y" or response == "y" or response == "N" or response == "n":
                          return response
                        else:
                          print(error)
                      except TypeError:
                        print(error)
                  #main program
                  print("You have your limit of Paradise Ducks, if you shoot any more you will be in trouble!")
                  #question to be asked
                  home3 = yes_no_check("You have you limit on Paradise Ducks, do you wish to head home? y/n")
                  #program will only continue once Y or N is entered
                  if home3 == "Y" or home3 == "y":
                    print("You head home with your ducks and have a delicious roast duck for dinner.")
                    sleep(4)
                    print("Thanks for playing my Duck Hunting Game!")
                    sleep(2) #final score
                    print("------------------------")
                    sleep(2)
                    print"Mallard Ducks Shot  =",mallard
                    sleep(2)
                    print"Grey Ducks Shot     =",grey
                    sleep(2)
                    print"Paradise Ducks Shot =",paradise
                    sleep(2)
                    print"Canadian Geese Shot =",canadian
                    sleep(2)
                    print"Black Swan Shot     =",swan
                    sleep(2)
                    print"Teal Ducks Shot     =",teal
                    sleep(2)
                    print"Rangers Shot        =",ranger
                    sleep(2)
                    print"Hunters Shot        =",hunter
                    sleep(2)
                    print("------------------------")
                    break
                  elif home3 == "N" or home3 == "n":
                    print("Ok, you just can't shoot anymore Paradise Ducks.")
                elif paradise <=6:
                  paradise=paradise+1
                  sleep(1)
                  print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job" #paradise shot
              elif rps_choice == "Swan" and swan <=21:
                sleep(1)
                if swan >=21:
                  print("You shot more than your limit of Swan. They take your license, gun, boat and car. They also give you a fine of $2000.") #$2000 fine
                  sleep(2) #final score
                  print("------------------------")
                  sleep(2)
                  print"Mallard Ducks Shot  =",mallard
                  sleep(2)
                  print"Grey Ducks Shot     =",grey
                  sleep(2)
                  print"Paradise Ducks Shot =",paradise
                  sleep(2)
                  print"Canadian Geese Shot =",canadian
                  sleep(2)
                  print"Black Swan Shot     =",swan
                  sleep(2)
                  print"Teal Ducks Shot     =",teal
                  sleep(2)
                  print"Rangers Shot        =",ranger
                  sleep(2)
                  print"Hunters Shot        =",hunter
                  sleep(2)
                  print("------------------------")
                  break
                elif swan >=20:
                  #function to check yes or no only entered = works with any question
                  def yes_no_check(question):
                    valid = False
                    while not valid:   #it will keep asking the question until it gets y or n
                      error = "Please enter Y or N"
                      try:
                        response = input(question)
                        if response == "Y" or response == "y" or response == "N" or response == "n":
                          return response
                        else:
                          print(error)
                      except TypeError:
                        print(error)
                  #main program
                  print("You have enough Swan. Don't be greedy leave some for others!")
                  #question to be asked
                  home4 = yes_no_check("You have you limit on Swan, do you wish to head home? y/n")
                  #program will only continue once Y or N is entered
                  if home4 == "Y" or home4 == "y":
                    print("You head home with your ducks and have a delicious roast duck for dinner.")
                    sleep(4)
                    print("Thanks for playing my Duck Hunting Game!")
                    sleep(2) #score
                    print("------------------------")
                    sleep(2)
                    print"Mallard Ducks Shot  =",mallard
                    sleep(2)
                    print"Grey Ducks Shot     =",grey
                    sleep(2)
                    print"Paradise Ducks Shot =",paradise
                    sleep(2)
                    print"Canadian Geese Shot =",canadian
                    sleep(2)
                    print"Black Swan Shot     =",swan
                    sleep(2)
                    print"Teal Ducks Shot     =",teal
                    sleep(2)
                    print"Rangers Shot        =",ranger
                    sleep(2)
                    print"Hunters Shot        =",hunter
                    sleep(2)
                    print("------------------------")
                    break
                  elif home4 == "N" or home4 == "n":
                    print("Ok, you just can't shoot anymore Swan.")
                elif swan <=21:
                  swan=swan+1
                  print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job" #swan shot
              elif rps_choice == "Canadian Goose" and canadian >=21:
                sleep(1)
                if canadian >=21:
                  print("You shot more than your limit of Canadian. They take your license, gun, boat and car. They also give you a fine of $2000.") #$2000 fine
                  sleep(2) #tally
                  print("------------------------")
                  sleep(2)
                  print"Mallard Ducks Shot  =",mallard
                  sleep(2)
                  print"Grey Ducks Shot     =",grey
                  sleep(2)
                  print"Paradise Ducks Shot =",paradise
                  sleep(2)
                  print"Canadian Geese Shot =",canadian
                  sleep(2)
                  print"Black Swan Shot     =",swan
                  sleep(2)
                  print"Teal Ducks Shot     =",teal
                  sleep(2)
                  print"Rangers Shot        =",ranger
                  sleep(2)
                  print"Hunters Shot        =",hunter
                  sleep(2)
                  print("------------------------")
                  break
                elif canadian >=20:
                  #function to check yes or no only entered = works with any question
                  def yes_no_check(question):
                    valid = False
                    while not valid:   #it will keep asking the question until it gets y or n
                      error = "Please enter Y or N"
                      try:
                        response = input(question)
                        if response == "Y" or response == "y" or response == "N" or response == "n":
                          return response
                        else:
                          print(error)
                      except TypeError:
                        print(error)
                  #main program
                  print("You have enough Canadian Geese. Don't be greedy leave some for others!")
                  #question to be asked
                  home5 = yes_no_check("You have you limit on Canadian Geese, do you wish to head home? y/n")
                  #program will only continue once Y or N is entered
                  if home5 == "Y" or home5 == "y":
                    print("You head home with your ducks and have a delicious roast duck for dinner.")
                    sleep(4)
                    print("Thanks for playing my Duck Hunting Game!")
                    sleep(2) #final score
                    print("------------------------")
                    sleep(2)
                    print"Mallard Ducks Shot  =",mallard
                    sleep(2)
                    print"Grey Ducks Shot     =",grey
                    sleep(2)
                    print"Paradise Ducks Shot =",paradise
                    sleep(2)
                    print"Canadian Geese Shot =",canadian
                    sleep(2)
                    print"Black Swan Shot     =",swan
                    sleep(2)
                    print"Teal Ducks Shot     =",teal
                    sleep(2)
                    print"Rangers Shot        =",ranger
                    sleep(2)
                    print"Hunters Shot        =",hunter
                    sleep(2)
                    print("------------------------")
                    break
                  elif home5 == "N" or home5 == "n":
                    print("Ok, you just can't shoot anymore Canadian Geese.")
                elif canadian <=21:
                  canadian=canadian+1
                  print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job" #canadian shot
            elif choice == "3":
              sleep(1)
              print"It took", choice, "shots each. Yet you and", friend1, "still missed the", rps_choice,", better luck next time." #3 shots and yet you still missed.
          elif duck1 == "N" or duck1 == "n":
            sleep(1)
            if rps_choice == "Hunter" or rps_choice == "Ranger" or rps_choice == "Teal":
              print("That's a wise choice mate. Good on ya!") #a wise choice
            elif rps_choice == "Mallard Duck" or rps_choice == "Grey Duck" or rps_choice == "Paradise Duck" or rps_choice == "Swan" or rps_choice == "Canadian Goose":
              print("That would have been a great shot!")
        if mallard >=6 and grey >=6 and paradise >=6 and swan >=20 and canadian >=20 and hunter >=3 and ranger >=2 and teal >=4: #max birds shot
          break
        else:
          continue
    else:
      print("That's nice.")
      sleep(2) #final game score
      print("------------------------")
      sleep(2)
      print"Mallard Ducks Shot  =",mallard
      sleep(2)
      print"Grey Ducks Shot     =",grey
      sleep(2)
      print"Paradise Ducks Shot =",paradise
      sleep(2)
      print"Canadian Geese Shot =",canadian
      sleep(2)
      print"Black Swan Shot     =",swan
      sleep(2)
      print"Teal Ducks Shot     =",teal
      sleep(2)
      print"Rangers Shot        =",ranger
      sleep(2)
      print"Hunters Shot        =",hunter
      sleep(2)
      print("------------------------")
    sleep(2) #final game score
    print("------------------------")
    sleep(2)
    print"Mallard Ducks Shot  =",mallard
    sleep(2)
    print"Grey Ducks Shot     =",grey
    sleep(2)
    print"Paradise Ducks Shot =",paradise
    sleep(2)
    print"Canadian Geese Shot =",canadian
    sleep(2)
    print"Black Swan Shot     =",swan
    sleep(2)
    print"Teal Ducks Shot     =",teal
    sleep(2)
    print"Rangers Shot        =",ranger
    sleep(2)
    print"Hunters Shot        =",hunter
    sleep(2)
    print("------------------------")
elif continue1 == "N" or continue1 == "n":
  sleep(1) #final game score
  print("Ok, Thanks for trialing my game.")
  sleep(2)
  print("------------------------")
  sleep(2)
  print"Mallard Ducks Shot  =",mallard
  sleep(2)
  print"Grey Ducks Shot     =",grey
  sleep(2)
  print"Paradise Ducks Shot =",paradise
  sleep(2)
  print"Canadian Geese Shot =",canadian
  sleep(2)
  print"Black Swan Shot     =",swan
  sleep(2)
  print"Teal Ducks Shot     =",teal
  sleep(2)
  print"Rangers Shot        =",ranger
  sleep(2)
  print"Hunters Shot        =",hunter
  sleep(2)
  print("------------------------")