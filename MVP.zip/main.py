print("Welcome to my Duck Hunting")
print("Here are the rules!")
print("You will be trialing the latest 12 gauge shotgun.")
age=0
gender=0
name = input("What would you like to be called?")
print"Hello", name
gen = input("What gender do you want your character to be? m/f")
if gen == "M" or "m":
  gender=1
elif gen == "F" or "f":
  gender=2
athletic = int(input("What age do you want your character to be?"))
age=athletic
print(age)
print("You will have a friend hunting with you of the same age.")
friend = input("What do you want your friends character name to be?")
setting = input("What do you want the day to be like, Fog, Blue Sky, Rain, Windy or Cloudy?")
print("On the lake you have an option to shoot Swan, Canadian Geese, Paradise Ducks, Mallards, or Greys")
gamebird = input("What type of waterfowl would you like to hunt?")
print"Great, you will enjoy hunting", gamebird
if gamebird == "Swan" or "swan":
  print("Swan")
  print("It's 5:30am on Opening Morning. You are ready to head up the lake in your duck boat.")
  continue1 = input("Do you wish to continue? y/n")
  if continue1 == "Y" or "y":
    print"Great, your friend is meeting you at the maimai. You hopped into the boat started the motor and you are heading up the lake in the", setting,"."
  elif continue1 == "N" or "n":
    print("Ok, Thanks for trialing my game.")
elif gamebird == "Canadian Geese" or "canadian geese":
  print("Canadian Geese")
  print("It's 5:30am on Opening Morning. You are ready to head up the lake in your duck boat.")
  continue2 = input("Do you wish to continue? y/n")
  if continue2 == "Y" or "y":
    print"Great, your friend is meeting you at the maimai. You hopped into the boat started the motor and you are heading up the lake in the", setting,"."
  elif continue2 == "N" or "n":
    print("Ok, Thanks for trialing my game.")
elif gamebird == "Paradise Ducks" or "paradise ducks":
  print("Paradise Ducks")
  print("It's 5:30am on Opening Morning. You are ready to head up the lake in your duck boat.")
  continue3 = input("Do you wish to continue? y/n")
  if continue3 == "Y" or "y":
    print"Great, your friend is meeting you at the maimai. You hopped into the boat started the motor and you are heading up the lake in the", setting,"."
  elif continue3 == "N" or "n":
    print("Ok, Thanks for trialing my game.")
elif gamebird == "Mallards" or "mallards":
  print("Mallards")
  print("It's 5:30am on Opening Morning. You are ready to head up the lake in your duck boat.")
  continue4 = input("Do you wish to continue? y/n")
  if continue4 == "Y" or "y":
    print"Great, your friend is meeting you at the maimai. You hopped into the boat started the motor and you are heading up the lake in the", setting,"."
  elif continue4 == "N" or "n":
    print("Ok, Thanks for trialing my game.")
elif gamebird == "Greys" or "greys":
  print("Greys")
  print("It's 5:30am on Opening Morning. You are ready to head up the lake in your duck boat.")
  continue5 = input("Do you wish to continue? y/n")
  if continue5 == "Y" or "y":
    print"Great, your friend is meeting you at the maimai. You hopped into the boat started the motor and you are heading up the lake in the", setting,"."
  elif continue5 == "N" or "n":
    print("Ok, Thanks for trialing my game.")
if age <= 16:
  print("Very young")
elif age <= 30:
  print("Young")
elif age <= 60:
  print("Old")
elif age >= 61:
  print("Ancient")