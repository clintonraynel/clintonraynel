print("Welcome to my Duck Hunting")
print("You will be trialing a 12 gauge shotgun.")
gun = input("What type of shotgun do you want to use?")
print"Great,", gun,"is an excelent choice."
mallard=0
grey=0
paradise=0
canadian=0
swan=0
teal=0
ranger=0
friend=0
hunter=0
time=0
name = input("What would you like to be called?")
print"Hello", name
print("You will have a friend hunting with you.")
friend1 = input("What do you want your friends character name to be?")
setting = input("What do you want the day to be like, Fog, Blue Sky, Rain, Windy or Cloudy?")
print("On the lake you have an option to shoot Swan, Canadian Geese, Paradise Ducks, Mallards, or Greys.")
input()
print("You can only hunt these birds, if you shoot any other species the game will stop and you will have your license taken!")
input()
print("It's 5:30am on Opening Morning. You are ready to head up the lake in your duck boat.")
continue1 = input("Do you wish to continue? y/n")
if continue1 == "Y" or continue1 == "y":
  print"Great, your friend is meeting you at the maimai. You hopped into the boat started the motor and you are heading up the lake in the", setting
  print"After a 15 minute trip up the lake you arrive at the maimai. Your friend,", friend1, "is already there."
  print"Waiting in the maimai with,", friend1, "you hear the first shots but it is still too early."
  print"You know you shouldn't but you see a duck flying in range."
  early1 = input("Do you shoot it? y/n")
  if early1 == "Y" or early1 == "y":
    print("You stood up and shot it cleanly with one shot.")
    teal=teal+1
    print("Your friends dog retrieved it and it turned out to be a teal. Teals are illegal to shoot.")
    print"You turn around as a ranger knocks on the door."
    ranger1 = input("Do you wish to shoot the ranger? y/n")
    if ranger1 == "Y" or ranger1 == "y":
      print"You know you will be in trouble anyway so you shoot the ranger.", friend1, "calls you an idiot, says he will report you and leaves."
      ranger=ranger+1
      murder = input("Should you shoot your friend aswell? y/n")
      if murder == "Y" or murder == "y":
        print"You shoot", friend1, "aswell thinking, no one knows now."
        friend=friend+1
        print("You leave before anyone finds out.")
        print("Two weeks later the police turn up and arrest you saying you are in for life sentence. You cannot escape!")
        print("------------------------")
        print"Mallard Ducks Shot  =",mallard
        print"Grey Ducks Shot     =",grey
        print"Paradise Ducks Shot =",paradise
        print"Canadian Geese Shot =",canadian
        print"Black Swan Shot     =",swan
        print"Teal Ducks Shot     =",teal
        print"Rangers Shot        =",ranger
        print"Hunters Shot        =",hunter
        print"Friends Shot        =",friend
        print("------------------------")
      elif murder == "N" or murder == "n":
        print("You leave before anyone finds out.")
        print("Two weeks later the police turn up and arrest you saying you are in for life sentence. You cannot escape!")
        print("------------------------")
        print"Mallard Ducks Shot  =",mallard
        print"Grey Ducks Shot     =",grey
        print"Paradise Ducks Shot =",paradise
        print"Canadian Geese Shot =",canadian
        print"Black Swan Shot     =",swan
        print"Teal Ducks Shot     =",teal
        print"Rangers Shot        =",ranger
        print"Hunters Shot        =",hunter
        print"Friends Shot        =",friend
        print("------------------------")
    elif ranger1 == "N" or ranger1 == "n":
      print("That's lucky as he had a mate with him. They take your license, gun, boat and car. They also give you a fine of $2000.")
      print("------------------------")
      print"Mallard Ducks Shot  =",mallard
      print"Grey Ducks Shot     =",grey
      print"Paradise Ducks Shot =",paradise
      print"Canadian Geese Shot =",canadian
      print"Black Swan Shot     =",swan
      print"Teal Ducks Shot     =",teal
      print"Rangers Shot        =",ranger
      print"Hunters Shot        =",hunter
      print"Friends Shot        =",friend
      print("------------------------")
  elif early1 == "N" or early1 == "n":
    print("Good decision as you know there are some rangers about this morning.")
    print("For every loop you have one game bird fly past.")
    time = int(input("How loops do you want to play for?"))
    for x in range(0, time):
      import random
      token = ["Hunter", "Ranger", "Teal", "Mallard Duck", "Grey Duck", "Paradise Duck", "Swan", "Canadian Goose", "Mallard Duck", "Grey Duck", "Paradise Duck", "Swan", "Mallard Duck", "Grey Duck", "Paradise Duck", "Grey Duck", "Paradise Duck"]
      rps_choice = random.choice(token)
      print(rps_choice)
      if rps_choice == "Hunter" or rps_choice == "Ranger":
        print"Through the", setting, "you see a", rps_choice, "close enough to shoot."
        duck2 = input("Do you wish to shoot him?")
        if duck2 == "Y" or "y":
          import random
          token = ["1", "2", "3"]
          choice1 = random.choice(token)
          print(choice1)
          if choice1 == "1":
            if rps_choice == "Hunter" and hunter <=4:
              if hunter >=4:
                print("The Rangers turn up and arrest you saying you are in for life sentence. You cannot escape!")
                break
              elif hunter >=3:
                print("You have shot 3 or more Hunters, if you shoot any more you will be in trouble!")
                home6 = input("Do you wish to head home before the rangers find out? y/n")
                if home6 == "Y" or home6 == "y":
                  print("You leave before anyone finds out.")
                  print("You head home with your ducks and have a delicious roast duck for dinner.")
                  print("Two weeks later the police turn up and arrest you saying you are in for life sentence. You cannot escape!")
                  print("Thanks for playing my Duck Hunting Game!")
                  break
                elif home6 == "N" or home6 == "n":
                  print("The Rangers turn up and arrest you saying you are in for life sentence. You cannot escape!")
              elif hunter <=3:
                hunter=hunter+1
                print"Great shots, it only took", choice1, "shot each. You and", friend1, "got the", rps_choice,", good job"
            if rps_choice == "Ranger" and ranger <=3:
              if ranger >=3:
                print("The Rangers turn up and arrest you saying you are in for life sentence. You cannot escape!")
                break
              elif ranger >=2:
                print("You have shot 2 or more Rangers, if you shoot any more you will be in trouble!")
                home7 = input("Do you wish to head home before the other rangers find out? y/n")
                if home7 == "Y" or home7 == "y":
                  print("You leave before anyone finds out.")
                  print("You head home with your ducks and have a delicious roast duck for dinner.")
                  print("Two weeks later the police turn up and arrest you saying you are in for life sentence. You cannot escape!")
                  print("Thanks for playing my Duck Hunting Game!")
                  break
                elif home7 == "N" or home7 == "n":
                  print("The Rangers turn up and arrest you saying you are in for life sentence. You cannot escape!")
              elif ranger <=3:
                ranger=ranger+1
                print"Great shots, it only took", choice1, "shot each. You and", friend1, "got the", rps_choice,", good job"
          elif choice1 == "2":
            if rps_choice == "Hunter" and hunter <=4:
              if hunter >=4:
                print("The Rangers turn up and arrest you saying you are in for life sentence. You cannot escape!")
                break
              elif hunter >=3:
                print("You have shot 3 or more Hunters, if you shoot any more you will be in trouble!")
                home6 = input("Do you wish to head home before the rangers find out? y/n")
                if home6 == "Y" or home6 == "y":
                  print("You leave before anyone finds out.")
                  print("You head home with your ducks and have a delicious roast duck for dinner.")
                  print("Two weeks later the police turn up and arrest you saying you are in for life sentence. You cannot escape!")
                  print("Thanks for playing my Duck Hunting Game!")
                  break
                elif home6 == "N" or home6 == "n":
                  print("The Rangers turn up and arrest you saying you are in for life sentence. You cannot escape!")
              elif hunter <=3:
                hunter=hunter+1
                print"Great shots, it only took", choice1, "shot each. You and", friend1, "got the", rps_choice,", good job"
            if rps_choice == "Ranger" and ranger <=3:
              if ranger >=3:
                print("The Rangers turn up and arrest you saying you are in for life sentence. You cannot escape!")
                break
              elif ranger >=2:
                print("You have shot 2 or more Rangers, if you shoot any more you will be in trouble!")
                home7 = input("Do you wish to head home before the other rangers find out? y/n")
                if home7 == "Y" or home7 == "y":
                  print("You leave before anyone finds out.")
                  print("You head home with your ducks and have a delicious roast duck for dinner.")
                  print("Two weeks later the police turn up and arrest you saying you are in for life sentence. You cannot escape!")
                  print("Thanks for playing my Duck Hunting Game!")
                  break
                elif home7 == "N" or home7 == "n":
                  print("The Rangers turn up and arrest you saying you are in for life sentence. You cannot escape!")
              elif ranger <=3:
                ranger=ranger+1
                print"Great shots, it only took", choice1, "shot each. You and", friend1, "got the", rps_choice,", good job"
          elif choice1 == "3":
            print"It took", choice1, "shots each. Yet you and", friend1, "missed the", rps_choice,", better luck next time."
      elif rps_choice == "Teal" or rps_choice == "Mallard Duck" or rps_choice == "Grey Duck" or rps_choice == "Paradise Duck" or rps_choice == "Swan" or rps_choice == "Canadian Goose":
        print"Through the", setting, "you see a", rps_choice, "close enough to shoot."
        duck1 = input("Do you wish to shoot the bird? y/n")
        if duck1 == "Y" or duck1 == "y":
          import random
          token = ["1", "2", "3"]
          choice = random.choice(token)
          print(choice)
          if choice == "1":
            if rps_choice == "Teal" and teal <=5:
              if teal >=5:
                print("You shot more than your limit of Grey Ducks. They take your license, gun, boat and car. They also give you a fine of $2000.")
                break
              elif teal >=4:
                print("You enough Teal, if you shoot any more you will be in trouble!")
                home8 = input("Do you wish to head home? y/n")
                if home8 == "Y" or home8 == "y":
                  print("You head home with your ducks and have a delicious roast duck for dinner.")
                  print("Thanks for playing my Duck Hunting Game!")
                  break
                elif home8 == "N" or home8 == "n":
                  print("Ok, you just can't shoot anymore Teal.")
              elif teal <=5:
                teal=teal+1
                print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job"
            if rps_choice == "Mallard Duck" and mallard <=7:
              if mallard >=7:
                print("You shot more than your limit of Mallard Ducks. They take your license, gun, boat and car. They also give you a fine of $2000.")
                break
              elif mallard >=6:
                print("You have your limit of Mallard Ducks, if you shoot any more you will be in trouble!")
                home1 = input("You have you limit on Mallard Ducks, do you wish to head home? y/n")
                if home1 == "Y" or home1 == "y":
                  print("You head home with your ducks and have a delicious roast duck for dinner.")
                  print("Thanks for playing my Duck Hunting Game!")
                  break
                elif home1 == "N" or home1 == "n":
                  print("Ok, you just can't shoot anymore Mallard Ducks.")
              elif mallard <=6:
                mallard=mallard+1
                print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job"
            elif rps_choice == "Grey Duck" and grey <=7:
              if grey >=7:
                print("You shot more than your limit of Grey Ducks. They take your license, gun, boat and car. They also give you a fine of $2000.")
                break
              elif grey >=6:
                print("You have your limit of Grey Ducks, if you shoot any more you will be in trouble!")
                home2 = input("You have you limit on Grey Ducks, do you wish to head home? y/n")
                if home2 == "Y" or home2 == "y":
                  print("You head home with your ducks and have a delicious roast duck for dinner.")
                  print("Thanks for playing my Duck Hunting Game!")
                  break
                elif home2 == "N" or home2 == "n":
                  print("Ok, you just can't shoot anymore Grey Ducks.")
              elif grey <=6:
                grey=grey+1
                print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job"
            elif rps_choice == "Paradise Duck" and paradise <=7:
              if paradise >=7:
                print("You shot more than your limit of Paradise Ducks. They take your license, gun, boat and car. They also give you a fine of $2000.")
                break
              elif paradise >=6:
                print("You have your limit of Paradise Ducks, if you shoot any more you will be in trouble!")
                home3 = input("You have you limit on Paradise Ducks, do you wish to head home? y/n")
                if home3 == "Y" or home3 == "y":
                  print("You head home with your ducks and have a delicious roast duck for dinner.")
                  print("Thanks for playing my Duck Hunting Game!")
                  break
                elif home3 == "N" or home3 == "n":
                  print("Ok, you just can't shoot anymore Paradise Ducks.")
              elif paradise <=6:
                paradise=paradise+1
                print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job"
            elif rps_choice == "Swan" and swan <=21:
              if swan >=21:
                print("You shot more than your limit of Swan. They take your license, gun, boat and car. They also give you a fine of $2000.")
                break
              elif swan >=20:
                print("You have enough Swan. Don't be greedy leave some for others!")
                home4 = input("You have you limit on Swan, do you wish to head home? y/n")
                if home4 == "Y" or home4 == "y":
                  print("You head home with your ducks and have a delicious roast duck for dinner.")
                  print("Thanks for playing my Duck Hunting Game!")
                  break
                elif home4 == "N" or home4 == "n":
                  print("Ok, you just can't shoot anymore Swan.")
              elif swan <=21:
                swan=swan+1
                print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job"
            elif rps_choice == "Canadian Goose" and canadian >=21:
              if canadian >=21:
                print("You shot more than your limit of Canadian. They take your license, gun, boat and car. They also give you a fine of $2000.")
                break
              elif canadian >=20:
                print("You have enough Canadian Geese. Don't be greedy leave some for others!")
                home5 = input("You have you limit on Canadian Geese, do you wish to head home? y/n")
                if home5 == "Y" or home5 == "y":
                  print("You head home with your ducks and have a delicious roast duck for dinner.")
                  print("Thanks for playing my Duck Hunting Game!")
                  break
                elif home5 == "N" or home5 == "n":
                  print("Ok, you just can't shoot anymore Canadian Geese.")
              elif canadian <=21:
                canadian=canadian+1
                print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job"
          elif choice == "2":
            if rps_choice == "Teal" and teal <=5:
              if teal >=5:
                print("You shot more than your limit of Grey Ducks. They take your license, gun, boat and car. They also give you a fine of $2000.")
                break
              elif teal >=4:
                print("You enough Teal, if you shoot any more you will be in trouble!")
                home8 = input("Do you wish to head home? y/n")
                if home8 == "Y" or home8 == "y":
                  print("You head home with your ducks and have a delicious roast duck for dinner.")
                  print("Thanks for playing my Duck Hunting Game!")
                  break
                elif home8 == "N" or home8 == "n":
                  print("Ok, you just can't shoot anymore Teal.")
              elif teal <=5:
                teal=teal+1
                print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job"
            if rps_choice == "Mallard Duck" and mallard <=7:
              if mallard >=7:
                print("You shot more than your limit of Mallard Ducks. They take your license, gun, boat and car. They also give you a fine of $2000.")
                break
              elif mallard >=6:
                print("You have your limit of Mallard Ducks, if you shoot any more you will be in trouble!")
                home1 = input("You have you limit on Mallard Ducks, do you wish to head home? y/n")
                if home1 == "Y" or home1 == "y":
                  print("You head home with your ducks and have a delicious roast duck for dinner.")
                  print("Thanks for playing my Duck Hunting Game!")
                  break
                elif home1 == "N" or home1 == "n":
                  print("Ok, you just can't shoot anymore Mallard Ducks.")
              elif mallard <=6:
                mallard=mallard+1
                print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job"
            elif rps_choice == "Grey Duck" and grey <=7:
              if grey >=7:
                print("You shot more than your limit of Grey Ducks. They take your license, gun, boat and car. They also give you a fine of $2000.")
                break
              elif grey >=6:
                print("You have your limit of Grey Ducks, if you shoot any more you will be in trouble!")
                home2 = input("You have you limit on Grey Ducks, do you wish to head home? y/n")
                if home2 == "Y" or home2 == "y":
                  print("You head home with your ducks and have a delicious roast duck for dinner.")
                  print("Thanks for playing my Duck Hunting Game!")
                  break
                elif home2 == "N" or home2 == "n":
                  print("Ok, you just can't shoot anymore Grey Ducks.")
              elif grey <=6:
                grey=grey+1
                print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job"
            elif rps_choice == "Paradise Duck" and paradise <=7:
              if paradise >=7:
                print("You shot more than your limit of Paradise Ducks. They take your license, gun, boat and car. They also give you a fine of $2000.")
                print("------------------------")
                print"Mallard Ducks Shot  =",mallard
                print"Grey Ducks Shot     =",grey
                print"Paradise Ducks Shot =",paradise
                print"Canadian Geese Shot =",canadian
                print"Black Swan Shot     =",swan
                print"Teal Ducks Shot     =",teal
                print"Rangers Shot        =",ranger
                print"Hunters Shot        =",hunter
                print"Friends Shot        =",friend
                print("------------------------")
              break
              elif paradise >=6:
                print("You have your limit of Paradise Ducks, if you shoot any more you will be in trouble!")
                home3 = input("You have you limit on Paradise Ducks, do you wish to head home? y/n")
                if home3 == "Y" or home3 == "y":
                  print("You head home with your ducks and have a delicious roast duck for dinner.")
                  print("Thanks for playing my Duck Hunting Game!")
                  print("------------------------")
                  print"Mallard Ducks Shot  =",mallard
                  print"Grey Ducks Shot     =",grey
                  print"Paradise Ducks Shot =",paradise
                  print"Canadian Geese Shot =",canadian
                  print"Black Swan Shot     =",swan
                  print"Teal Ducks Shot     =",teal
                  print"Rangers Shot        =",ranger
                  print"Hunters Shot        =",hunter
                  print"Friends Shot        =",friend
                  print("------------------------")
                break
                elif home3 == "N" or home3 == "n":
                  print("Ok, you just can't shoot anymore Paradise Ducks.")
              elif paradise <=6:
                paradise=paradise+1
                print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job"
            elif rps_choice == "Swan" and swan <=21:
              if swan >=21:
                print("You shot more than your limit of Swan. They take your license, gun, boat and car. They also give you a fine of $2000.")
                print("------------------------")
                print"Mallard Ducks Shot  =",mallard
                print"Grey Ducks Shot     =",grey
                print"Paradise Ducks Shot =",paradise
                print"Canadian Geese Shot =",canadian
                print"Black Swan Shot     =",swan
                print"Teal Ducks Shot     =",teal
                print"Rangers Shot        =",ranger
                print"Hunters Shot        =",hunter
                print"Friends Shot        =",friend
                print("------------------------")
              break
              elif swan >=20:
                print("You have enough Swan. Don't be greedy leave some for others!")
                home4 = input("You have you limit on Swan, do you wish to head home? y/n")
                if home4 == "Y" or home4 == "y":
                  print("You head home with your ducks and have a delicious roast duck for dinner.")
                  print("Thanks for playing my Duck Hunting Game!")
                  print("------------------------")
                  print"Mallard Ducks Shot  =",mallard
                  print"Grey Ducks Shot     =",grey
                  print"Paradise Ducks Shot =",paradise
                  print"Canadian Geese Shot =",canadian
                  print"Black Swan Shot     =",swan
                  print"Teal Ducks Shot     =",teal
                  print"Rangers Shot        =",ranger
                  print"Hunters Shot        =",hunter
                  print"Friends Shot        =",friend
                  print("------------------------")
                break
                elif home4 == "N" or home4 == "n":
                  print("Ok, you just can't shoot anymore Swan.")
              elif swan <=21:
                swan=swan+1
                print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job"
            elif rps_choice == "Canadian Goose" and canadian >=21:
              if canadian >=21:
                print("You shot more than your limit of Canadian. They take your license, gun, boat and car. They also give you a fine of $2000.")
                print("------------------------")
                print"Mallard Ducks Shot  =",mallard
                print"Grey Ducks Shot     =",grey
                print"Paradise Ducks Shot =",paradise
                print"Canadian Geese Shot =",canadian
                print"Black Swan Shot     =",swan
                print"Teal Ducks Shot     =",teal
                print"Rangers Shot        =",ranger
                print"Hunters Shot        =",hunter
                print"Friends Shot        =",friend
                print("------------------------")
              break
              elif canadian >=20:
                print("You have enough Canadian Geese. Don't be greedy leave some for others!")
                home5 = input("You have you limit on Canadian Geese, do you wish to head home? y/n")
                if home5 == "Y" or home5 == "y":
                  print("You head home with your ducks and have a delicious roast duck for dinner.")
                  print("Thanks for playing my Duck Hunting Game!")
                  print("------------------------")
                  print"Mallard Ducks Shot  =",mallard
                  print"Grey Ducks Shot     =",grey
                  print"Paradise Ducks Shot =",paradise
                  print"Canadian Geese Shot =",canadian
                  print"Black Swan Shot     =",swan
                  print"Teal Ducks Shot     =",teal
                  print"Rangers Shot        =",ranger
                  print"Hunters Shot        =",hunter
                  print"Friends Shot        =",friend
                  print("------------------------")
                break
                elif home5 == "N" or home5 == "n":
                  print("Ok, you just can't shoot anymore Canadian Geese.")
              elif canadian <=21:
                canadian=canadian+1
                print"Great shots, it only took", choice, "shot each. You and", friend1, "got the", rps_choice,", good job"
          elif choice == "3":
            print"It took", choice, "shots each. Yet you and", friend1, "missed the", rps_choice,", better luck next time."
      elif duck1 == "N" or duck1 == "n":
        print("That would have been a great shot")
      elif mallard >=6 and grey >=6 and paradise >=6 and swan >=20 and canadian >=20 and hunter >=3 and ranger >=2 and teal >=4:
        break
    print("------------------------")
    print"Mallard Ducks Shot  =",mallard
    print"Grey Ducks Shot     =",grey
    print"Paradise Ducks Shot =",paradise
    print"Canadian Geese Shot =",canadian
    print"Black Swan Shot     =",swan
    print"Teal Ducks Shot     =",teal
    print"Rangers Shot        =",ranger
    print"Hunters Shot        =",hunter
    print"Friends Shot        =",friend
    print("------------------------")
elif continue1 == "N" or continue1 == "n":
  print("Ok, Thanks for trialing my game.")
  print("------------------------")
  print"Mallard Ducks Shot  =",mallard
  print"Grey Ducks Shot     =",grey
  print"Paradise Ducks Shot =",paradise
  print"Canadian Geese Shot =",canadian
  print"Black Swan Shot     =",swan
  print"Teal Ducks Shot     =",teal
  print"Rangers Shot        =",ranger
  print"Hunters Shot        =",hunter
  print"Friends Shot        =",friend
  print("------------------------")